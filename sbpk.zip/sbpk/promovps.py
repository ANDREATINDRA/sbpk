🔹️VPS CONOHA NON RENEW
2 Core 1GB = 100k 
3 Core 2GB =200k
4 Core 4GB = 360k 

🔹️VPS CONOHA RENEW
2 Core 1GB =120k
3 Core 2GB = 240k
4 Core 4GB = 420k 

🔹️VPS LINODE 
1 Core 2GB = 50k 
2 Core 4GB = 100K 
4 Core 8GB = 200K 
6 Core 16GB = 350K

Contact person

line.me/ti/p/~nananaaaaa.

line.me/ti/p/~sixtynine69_

line.me/ti/p/~ngapainsilo